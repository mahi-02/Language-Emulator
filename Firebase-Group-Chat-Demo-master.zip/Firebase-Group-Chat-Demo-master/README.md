# Firebase-Group-Chat-Demo

Sampe code integrated with firebase auth, firebase realtime database
