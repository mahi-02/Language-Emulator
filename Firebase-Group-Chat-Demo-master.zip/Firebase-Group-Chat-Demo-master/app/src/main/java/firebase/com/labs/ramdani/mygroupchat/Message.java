package firebase.com.labs.ramdani.mygroupchat;

/**
 * Created by ramdani on 9/18/16.
 */

public class Message {
    public String sender;
    public String message;
}
